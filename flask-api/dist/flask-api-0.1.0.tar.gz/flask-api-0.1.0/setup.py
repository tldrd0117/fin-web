# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['flask_api']

package_data = \
{'': ['*']}

install_requires = \
['Flask>=1.1.2,<2.0.0']

entry_points = \
{'console_scripts': ['app = flask_api.app:run']}

setup_kwargs = {
    'name': 'flask-api',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'tldrd0117',
    'author_email': 'tldrd0117@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
